# Campaign Memory: The Witchlight Veil

## Overview
- **Campaign:** The Witchlight Veil (Adapted from *The Wild Beyond the Witchlight*).
- **Style:** Social-heavy (80%), Character-driven, Emotional, Dark Comedy.
- **Session Duration:** 3-5 hours (Predefined 1 PM - 4/5 PM).
- **Core Theme:** Fate vs. Correction / The Veil between Desire and Reality.

## Current Narrative State (Session 7: The Magenta Fracture)
- **Location:** Hither, Prismeer. Specifically at the *Inn at the End of the Road*.
- **The Twist:** Aris (Lunaris Thoht) was kidnapped by Sowpig. Due to time dilation in the Feywild, 20 years passed for him while only 3 hours passed for the party.
- **Aris/Lunaris:** Now 28 years old, traumatized by abandonment. His "Thoht" persona is a manifestation of this trauma and survival instinct.
- **Current Goal:** Calm Aris/Lunaris, proceed through the *Brigands' Tollway* to *Downfall* to find Bavlorna Blightstraw and reclaim "Lost Things."

## Learned DM Preferences
- **Social Priority:** Prioritize dialogue, emotional beats, and complex negotiations over combat.
- **Combat as Social:** Even in combat (like vs. Thoht or Agdon), maintain a high level of verbal interaction and psychological stakes.
- **NPC Depth:** NPCs should be reactive to player backstories (e.g., Lunaris sensing "static" or specific emotions via Mirror Touch Synesthesia).
- **Pacing:** Allow scenes to breathe. Do not rush the "Social" parts, especially during deep-talk or memory exchanges.

## Key NPCs & Mechanics
- **Aris/Lunaris:** Mirror Touch Synesthesia (feels others' pain/emotions).
- **Tsu Harabax:** Caretaker of the walking inn, holds the history of Aris's 20-year stay.
- **Agdon Longscarf:** Boastful, fast, loves "happy memories" as tolls.
- **The Rule of Reciprocity:** Always emphasize the exchange of equal value (gifts, secrets, or memories).
- **Social Encounter Tools:**
    - *Stream of Visions:* Use for cryptic lore and backstory foreshadowing.
    - *Stilt Walkers:* Use for world-building and acknowledging Aris's long history in Hither.
    - *Marsh Gas:* Use for Dark Comedy and adding social hurdles to negotiations.

## Project Continuity
- **Reference Files:** `Original Adventures/The Witchlight Veil/` contains all session notes and character sheets.
- **Next Step:** Session 7 execution (Magenta Fracture -> Tollway -> Downfall arrival).
