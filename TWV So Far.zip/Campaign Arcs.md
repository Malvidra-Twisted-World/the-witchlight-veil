---
tags: [DnD, Campaign Planning, Witchlight Veil]
date: 2026-02-04
---

# Campaign Arcs: The Witchlight Veil

## Overview
This document outlines possible narrative threads weaving the player characters' backstories into *The Wild Beyond the Witchlight* module. The core theme is the tension between **Fate (The Hags)** and **Correction (The Party)**.

---

## The Aris Arc: "The Boy Who Left, The Man Who Returned"

### The Setup (Session 1 & Carnival)
*   **The Departure:** Madryck insists Aris accompanies the party. "He has dreams of the Carnival. He says a 'Pig Lady' waits for him. I cannot stop him."
*   **The Kidnapping:** In the **Hall of Illusions**, Aris is lured into a mirror by **Sowpig** (Skabatha's minion). He is drawn to her not by magic, but by his *Mirror Touch Synesthesia*—he feels her infinite hunger and naively thinks he can "heal" it.
*   **The Loss:** The party cannot follow immediately. The mirror closes. Aris is gone.

### The Twist (Hither - Chapter 2)
*   **Time Dilation:** Time moves differently in the Feywild. While days pass for the party, *decades* pass for Aris.
*   **The Reunion:** The party finds him not in Thither, but in **Hither** at the **Inn at the End of the Road**.
*   **The Change:** Aris is no longer a child. He is **Lunaris** (a name he chose), a 28-year-old warrior who works as the Inn's protector/bouncer to pay off a debt he believes he owes for his "abandonment."
*   **Class:** **Monk (Way of Mercy)** / **Blood Hunter**.
    *   *Why:* His synesthesia allows him to manipulate life force (Mercy Monk) but the "Witchlight" influence has twisted his blood (Blood Hunter). He hunts the "monsters" of his own nightmares.
*   **Conflict:** He doesn't want to leave. The Inn is the only place the "static" of the world is quiet. He blames the party for leaving him to the Pig Lady (Sowpig), from whom he barely escaped years ago.

---

## Character "Big Reveals" (Plot Twists)

### 1. Kee Chow Ma & Warduke (The Broken Oath)
**The Reveal:** The "random portal" that destroyed Kee's knightly order wasn't an accident. It was a test run.
*   **The Villain:** **Warduke** (League of Malevolence member, appearing in Prismeer).
*   **The Twist:** Warduke was hired by a rival kingdom to wipe out the order. He used a *Sphere of Annihilation* (or similar void magic).
*   **The Sword:** Kee's Hexblade isn't just a soul-eater; it contains the *souls of his fallen order*. They scream whenever Warduke is near. The sword *wants* Warduke's soul to free the others.
*   **Climax:** A duel with Warduke in the Palace of Hearts Desire.

### 2. Dr. Aurelia & The Clockwork Tragedy
**The Reveal:** Her abilities are not just magic; they are a rejection of Fate.
*   **The Villain:** **Endelyn Moongrave** (The Hag of the Future).
*   **Elaboration on "Clockwork":**
    *   **Philosophy:** Endelyn believes the future is a *script* that cannot be changed (Tragedy). Aurelia believes the future is a *machine* that can be repaired (Clockwork Soul).
    *   **The Connected Backstory:** The "Plague" Aurelia fought was actually a **Harvest**. Endelyn needed thousands of souls to power her *Orrery of Tragedies*. She wrote a "script" where the town died.
    *   **The Conflict:** Aurelia survived because she unconsciously "broke" the script. Now, Endelyn wants her back—not to kill her, but to make her the "Author" of the next Great Tragedy, forcing her to choose who lives and dies.
*   **Mechanic:** Aurelia might see "Plot Threads" (golden strings) on people. She can spend Sorcery Points to *cut* them, saving them from "Fated Damage" (Critical Hits).

#### Aurelia's Integration
*   **The Catalyst:** She joins the party at the tavern because she *calculated* that this specific gathering is a statistical anomaly. The "Notice" appearing is the variable she was waiting for.
*   **The Carnival Connection:** She might have visited the Carnival as a child (forgotten memory) or simply sensed its arrival as a disturbance in the timeline.
*   **The Hook:** Her pocket watch starts ticking backwards or stops entirely when she enters the Feywild Bleed.

### 3. Philip Nessryn & The Carnival's True Master
**The Reveal:** The Carnival Swap (Isolde $\leftrightarrow$ Witch/Light) is now a cage, and Philip is the key.
*   **The Nuance:** **Mister Witch & Mister Light** are *not* villains. They are desperate. They want the Coven gone as much as the players do, but they are paralyzed by the fear of being swapped back to the Shadowfell.
*   **The Twist:** They recognize Philip's potential and *want* to help him, but they can't be seen doing it. They will leave him "crumb trails" of information while publicly pretending to follow the Hags' rules.
*   **Philip's Role:** Philip represents the **Veil** (Mystery/Twilight). He was marked by the Carnival itself as the **Heir of Shadows**.
*   **The Choice (Endgame - Chapter 5):** This is a *long-term* arc.
    *   **Chapter 1:** Philip becomes the **Witchlight Monarch** (temporary title). This is the foreshadowing/tutorial.
    *   **Chapter 5:** In the Palace of Heart's Desire, he must choose whether to ascend as a permanently **Master** to void the Hags' contract.
    *   **Why wait?** He needs to understand the Hags (Hither/Thither/Yon) to understand *what* he is protecting the Carnival from.

### 4. Lorelei S. Duboise & The Marionette's Dress
**The Reveal:** Her "Sense of Fashion" wasn't just taste; it was her *Presence* (Charisma/Identity).
*   **The Villain:** **Endelyn Moongrave** (Shared with Aurelia).
*   **The Twist:** Endelyn didn't just steal a fashion sense; she stole Lorelei's **"Signature Look."** She uses this essence to craft the **Costumes of the Tragic Hero** in her theater.
    *   **The Horror:** Anyone who wears these costumes *becomes* the character Endelyn wrote, losing their free will. Lorelei feels a "phantom limb" sensation whenever she sees a puppet or actor in the Motherhorn.
*   **The Synergy (Aurelia & Lorelei):**
    *   **Aurelia** fights the *Script/Machine* of Fate.
    *   **Lorelei** fights the *Costume/Role* of Fate.
    *   Together, they can liberate the actors. Aurelia breaks the timeline; Lorelei "redesigns" the costumes to break the enchantment.
*   **Endgame Moment:** Lorelei must craft a **"Gown of Free Will"** (or similar item) to walk onto Endelyn's stage and *refuse* to play the role, shattering the Hag's power over the audience. (Prismeer's own "Fashion Week" rebellion).


---

## Campaign-Wide Threads

### The "Mirror" Theme
*   **Madryck & Aris:** Aris is a mirror of the party—innocent but damaged by magic.
*   **Zybilna vs. Iggwilv:** The Archfey is actually **Tasha/Iggwilv** (historically chaotic/evil figure trying to be good).
*   **The Party:** They are all "broken" people trying to fix a broken world.

### The "Veil" Mechanic
Since this campaign is called *The Witchlight Veil*, lean into the idea that the "Veil" is the barrier between **Reality** and **Desire**.
*   **The Hags** want to tear the Veil down and let nightmares rule.
*   **The Party** must stitch it back together—or decide if some lies (illusions) are worth keeping.

---

## DM Notes / Secrets
*   **Zybilna's Identity:** If Philip or Aurelia are high-INT characters, drop clues earlier that Zybilna's name is an anagram or that her history doesn't match standard Fey lore.
*   **The Sword's Voice:** Kee's sword should speak in riddles that only he hears, often commenting on the *taste* of the NPCs. (e.g., "This rabbit tastes... fast.")
