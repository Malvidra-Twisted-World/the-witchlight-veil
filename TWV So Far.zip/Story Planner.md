![[Witchlight Veil.png]]

# TL;DR;

This is a planner note for this campaign

## Module

- ### The Wild Beyond The Witchlight
	- #### Chapters
		- [[The Wild Beyond the Witchlight - Into the Feywild|Introduction]]
		- [[The Wild Beyond the Witchlight - Ch. 1 Witchlight Carnival|Chapter 1]]
	- Start Level 3 and progression start each chapter finished

## Players

- [ ] Derry as [[Philip Nessryn]]
- [ ] Eury as [[Dr. Aurelia Mortimer]]
- [ ] Choco as [[Kee Chow Ma]]
- [ ] Efernandes as [[D&D/Original Adventures/The Witchlight Veil/Players/Lorelei S. Duboise]]
- [ ] HerryArt as ? (New member met at Hither as Bavlorna's Hostage caged at her hanging cages)
- [ ] Rizaldy as ? (New member met at Hither as Bavlorna's Hostage caged at her hanging cages)

# Sessions

## Session 0

### Tasks

- [x] Lost Things Distribution ✅ 2026-02-04
	- [ ] Efernandes => Sense of Fashion -> Endelyn Moongrave => You can't open a door without knocking on it first.
	- [ ] Eury => Ability to Smile -> Bavlorna Blightstraw => You can't light nonmagical fires.
	- [ ] Derry => Sense of Direction -> Skabatha Nightshade => You can't tie or untie a nonmagical rope.
	- [ ] Choco => Ability to keep secrets -> Bavlorna Blightstraw => You can't light nonmagical fires.
	- [ ] Herry => Artistic Creativity -> Bavlorna Blightstraw => You can't light nonmagical fires.
	- [ ] Rizaldy => Handwriting -> Skabata Nighshide => You can't tie or untie a nonmagical rope.
- [x] Zybilna's Memories DIstribution ✅ 2026-02-04
	- [ ] Efernandes
		- [ ] You remember an older family member telling you about a woman with long white hair who helped deliver you when you were born.
	- [ ] Choco
		- [ ] You fell into an icy pond as a child and probably would have died had a woman matching Zybilna's description not fished you out of the cold water and wrapped you in a blanket.
	- [ ] Eury
		- [ ] When you were a small child, a woman matching Zybilna's description reunited you with a lost pet.
	- [ ] Derry
		- [ ] You used to have trouble speaking as a child until a woman matching Zybilna's description put her hand on your head.
	- [ ] Herry
		- [ ] A woman matching Zybilna's description visited you once when you were sick as a child and made you feel better.
	- [ ] Rizaldy
		- [ ] You used to have trouble speaking as a child until a woman matching Zybilna's description put her hand on your head.
### Trackers

#### Unicorn's Horn Location

Offered for sale at Trinket, Bauble, and Charm's in Downfall (see *area D10* in *chapter 2*)

## Session 1

### Concept

Para player akan bertemu di sebuah tavern bernama ==*The Wandering Bard Tavern*== dimiliki oleh seorang Satyr bernama [[Lampiar]] di kota ==*Tayuka*== di Regional ==*Dewasentra*==, dunia ==*Dewanegara*==.

Disini mereka tidak sengaja bertemu, dan terjadilah reuni dadakan, disini mereka akan bahas masa lalu termasuk problem masa kecil dulu membahas apa yang udah dikasih dari hook [[The Wild Beyond the Witchlight - Into the Feywild#Lost Things|Lost Things]]. Disini plot pointnya ada di job board yang ada di dalam tavern, dimana mereka akan menemukan selembaran quest yang sudah lama di tempel dan sudah tertiban beberapa lembaran quest yang baru lainnya.

Disinlah kita akan pakai Hook dari [[The Wild Beyond the Witchlight - Into the Feywild#Warlock's Quest|Warlock's Quest]] dimulai.

Saat tau soal misi, party akan berbincang untuk pergi ke tempat Madryck Roslof, tapi saat otw kesana, di dalam hutan, mereka akan sedikit kecipratan energi magis dari Feywild, ini momen untuk testing table Fey Curse, dimana pemain akan roll 1d100 yang masing-masing kutukan itu lebih ke prank dari Magic Fey. Disini juga terrain akan terlihat berbeda, lingkungan dan jalan yang mereka lewati persis mirip apa yang mereka lihat di Material Plane, tapi disini seperti pindah sesaat ke Feywild dimana walau mirip tapi warna dan bentuknya atau bahkan jenisnya tidak pernah merka lihat sebelumnya.

lalu setelah keluar dari hutan, Fey Curse yang dirasakan pemain akan hilang dan mereka sudah tiba di dekat rumah Madryck

Tambahan NPC di awal aku mau Madryck Roslof disini selain kondisi dan penghuni yang memang sudah ada di buku, dia juga punya anak angkat, anak laki laki sekitar umur 8 tahun yang di panggil Aris, (Nama Panjangnya Lunaris Thoht), ia diasuh Madryck saat bertemu di salah satu petualangan Madryck dahulu ketika Aris ditemukan tak sadarkan diri di dalam hutan, Aris mempunyai kelainan Mirror Touch Synthesisa, jadi ketika keluar Madryck selalu menutup mata Aris dengan kain tipis yang Aris bawa saat pertama kali bertemunya, untuk mengurangi efek dari kelainan tersebut.

Halaman Rumah Madryck penuh dengan Labu Raksasa sebesar Rumah sekitar 15 meter tingginya, tercium dari dalam bau pie labu sedang di masak. Saat mengetuk pintu, pintu akan dibuka oleh Aris yang akan bertemu dengan para pemain disini dan sisanya boleh di teruskan

# Player's Wish

- [[D&D/Original Adventures/The Witchlight Veil/Players/Lorelei S. Duboise|Lorelei S. Duboise]]: Dia ingin bertemu wanita yang ia temui dulu di carnival
- [[Dr. Aurelia Mortimer]]: Berharap suaminya tenang dan mendoakan yang terbaik
- [[Philip Nessryn]]: Ingin keliling dunia
- [[Kee Chow Ma]]: Holy Sword